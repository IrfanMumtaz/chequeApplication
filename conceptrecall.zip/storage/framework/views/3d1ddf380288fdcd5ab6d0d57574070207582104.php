<?php $__env->startSection('page_heading','Create Cheque'); ?>
<?php $__env->startSection('section'); ?>
           
           
	<ul>
	    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        <li><?php echo e($error); ?></li>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
	
	<?php if(session('success') == 1): ?>
		<div class="alert alert-success">
		  <strong>Success!</strong> Cheques has been sent for approval.
		</div>
	<?php elseif(session('success') == -1): ?>
		<div class="alert alert-danger">
		  <strong>Failed!</strong> Operation failed. Please try again.
		</div>
	<?php endif; ?>

	<form role="form" method="POST" action="create_cheque/store">
		<div class="form-group">
            <label>Name</label>
            <input class="form-control" type="text" name="name" pattern="[a-zA-Z\s]{1,50}" title="Input Accepts Alphabets Only" required="">
        </div>
        <div class="form-group">
            <label>Date</label>
            <input class="form-control" type="date" name="date" required="">
        </div>
        <div class="form-group">
            <label>Amount In Counting</label>
            <input class="form-control" type="text" name="amountIC" pattern="[0-9.,]{1,18}" title="Input Accepts Numbers Only" required="">
        </div>
        <div class="form-group">
            <label>Amount In Words</label>
            <input class="form-control" type="text" name="amountIW" pattern="[a-zA-Z\s]{1,255}" title="Input Accepts Alphabets Only" required="">
        </div>
        <div class="form-group">
        	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input class="form-control" type="submit" name="submit" value="submit">
        </div>
	</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>