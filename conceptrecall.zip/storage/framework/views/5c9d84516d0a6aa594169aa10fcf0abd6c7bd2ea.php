<?php $__env->startSection('page_heading','Cheques Approval'); ?>
<?php $__env->startSection('section'); ?>
    <div class="pull-left margin-bottom">
    	<a href="create_cheque" class="btn btn-primary">Create</a>
    </div>
           
	<table class="table table-striped table-bordered ">
		<thead>
			<tr>
				<th>S. No</th>
				<th>Name</th>
				<th>Amount In Words</th>
				<th>Amount In Counting</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		     <tr>
		     	<td><?php echo e($da->id); ?></td>
		     	<td><?php echo e($da->name); ?></td>
		     	<td><?php echo e($da->amount_inwords); ?></td>
		     	<td><?php echo e($da->amount); ?></td>
		     	<td>
		     		<?php if($da->approved == 0): ?>
		     		<span class="status<?php echo e($da->id); ?>">
			     		<form method="post">
			     			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			     			<input type="hidden" value="<?php echo e($da->id); ?>" name="cheque_id">
			     			<button type="submit" class="btn btn-info btn-xs ajax_form">Accept</button>
			     		</form>
		     		</span>
		     		<?php else: ?>
		     			<span class="status-success">Approved</span>
		     		<?php endif; ?>
		     	</td>
		     </tr>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	    
	</div>

	<?php echo e($data->links()); ?>


<script type="text/javascript">
	$(document).ready(function(){
	    $('form').on('submit', function(e){
	        e.preventDefault(e);
	        var cheque_id = $(this).children("input[name=cheque_id]").val();
	        var _token = $(this).children("input[name=_token]").val();

	        $.ajax({
	            type: "post",
	            url: "/request_approve",
	            data: {
	                'cheque_id': cheque_id,
	                '_token': _token,
	            },
	            success: function(data){
	            	if(data == 1){
	                	$(".status"+cheque_id).html('<span class="status-success">Approved</span>');
	            	}
	            	else{
	            		alert('Invalid Request Made')
	            	}
	            },
	            error: function(jqXHR, textStatus, errorThrown) { // What to do if we fail
			        console.log(JSON.stringify(jqXHR));
			        console.log("AJAX error: " + textStatus + ' : ' + errorThrown);
			    }
	        });
	    });
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>