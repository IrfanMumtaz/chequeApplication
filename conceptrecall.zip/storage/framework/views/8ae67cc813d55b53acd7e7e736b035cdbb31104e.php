<?php $__env->startSection('page_title'); ?>	Stats <?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>
<h2>Stats</h2>

	<?php echo $__env->make('widgets.stat', array('icon'=> 'whatsapp', 'header'=> 'Views', 'value'=>'71,842', 'href'=>'#', 'color'=>'primary'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	
	<?php echo $__env->make('widgets.stat', array('icon'=> 'archive', 'header'=> 'header', 'value'=>'19,968', 'href'=>'#', 'color'=>'info'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	
	<?php echo $__env->make('widgets.stat', array('icon'=> 'desktop', 'header'=> 'Header', 'value'=>'000', 'href'=>'#', 'color'=>'success'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	
	<?php echo $__env->make('widgets.stat', array('icon'=> 'folder', 'header'=> 'Title', 'value'=>'758,412,304', 'href'=>'#', 'color'=>'danger'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>