<!DOCTYPE html>
<html>
<head>
	<title>Print Cheque</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('assets/stylesheets/custom.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/app.css')); ?>">
</head>
<body>




	<div class="image">
		<img src="<?php echo e(URL::asset('assets/images/blank_cheque.jpg')); ?>" class="img-responsive">
		<div class="text_wrap">
			<p class="date"><?php echo e($results->date); ?></p>
			<div>
				<p class="name"><?php echo e($results->name); ?></p>
				<p class="amount">PKR <?php echo e($results->amount); ?>/-</p>
			</div>
			<p class="amountIW"><?php echo e($results->amount_inwords); ?></p>
		</div>

	</div>


</body>
</html>

