<?php $__env->startSection('page_heading','Cheques List'); ?>
<?php $__env->startSection('section'); ?>
    <div class="pull-left margin-bottom">
    	<a href="create_cheque" class="btn btn-primary">Create</a>
    </div>
           
	<table class="table table-striped table-bordered ">
		<thead>
			<tr>
				<th>S. No</th>
				<th>Name</th>
				<th>Amount In Words</th>
				<th>Amount In Counting</th>
				<th>Status</th>
			</tr>
		</thead>
		<tbody>
			<?php $sno = 1?>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		     <tr>
		     	<td><?php echo e($sno++); ?></td>
		     	<td><?php echo e($da->name); ?></td>
		     	<td><?php echo e($da->amount_inwords); ?></td>
		     	<td><?php echo e($da->amount); ?></td>
		     	<td>
		     		<?php if($da->approved == 1): ?>
		     			<span class="status-success">Approved</span>
		     			<form method="post" action="/cheque_print" id="print_form">
		     				<input type="hidden" name="cheque_id" value="<?php echo e($da->id); ?>">
		     				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		     				<button type="submit" class="btn btn-success btn-xs">Print</button>
		     			</form>
		     		<?php else: ?>
		     			<span class="status-failed">Pending</span>
		     		<?php endif; ?>
		     	</td>
		     </tr>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	    
	</div>

	<?php echo e($data->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>