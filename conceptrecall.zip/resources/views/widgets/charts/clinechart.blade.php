
<canvas id="cline" width="350" height="220"></canvas>